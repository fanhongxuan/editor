# GLOBAL_Win32
This is a mirror of http://adoxa.altervista.org/global/
GNU GLOBAL is a source code tag system that works the same way across diverse environments. 
It supports C, C++, Yacc, Java, PHP4 and assembly source code. 
This is the DOS and Win32 ports.
About the details, see http://adoxa.altervista.org/global/
